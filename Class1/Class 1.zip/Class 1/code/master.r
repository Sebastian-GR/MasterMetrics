# Master file

# Dont set again working directory in each file
setwd("G:/My Drive/Econometría y estadística/Material mío/Switala/Class 1")

# Run in correct order the files
source("code/simulate_data.r")
source("code/example1.r")
source("code/example2.r")
